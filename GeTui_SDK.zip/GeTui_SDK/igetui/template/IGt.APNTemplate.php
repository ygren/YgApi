<?php

/**
 * Created by PhpStorm.
 * User: Kevin
 * Date: 14-9-4
 * Time: 下午2:12
 */
class IGtAPNTemplate extends IGtBaseTemplate
{

} 